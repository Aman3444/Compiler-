Standard Tests

T1. The file ass1ai.out is produced by the following command line

buffer.exe ass1.pls additive > ass1ai.out

T2. The file ass1mi.out is produced by the following command line

buffer.exe ass1.pls multiplicative > ass1mi.out

T3. The file ass1fi.out is produced by the following command line

buffer.exe ass1.pls fixed > ass1fi.out

T4. The file ass1e.out is produced by the following command line

buffer.exe ass1e.pls fixed > ass1e.out

REMINDER:
The output files produced by your buffer program
MUST be identical bit by bit to the provided output test files.